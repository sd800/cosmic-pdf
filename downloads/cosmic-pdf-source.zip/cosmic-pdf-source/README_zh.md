# <img src="extension/icons/icon-128.png" width="96" align="right" alt=""> Cosmic PDF<br clear="right">

[English](README.md)

Cosmic PDF 是一款提供 PDF 阅读深色模式的 Chrome 扩展，配备可自定义的阅读器、本地文字识别和 AI 解释功能。

## PDF 阅读深色模式

将 PDF 页面与查看器背景一同切换为深色，扫描件也能使用。您可以随时切换为浅色模式，不改变原始文件。

阅读器使用独立的扩展页面，避免网页深色模式扩展重复染色。

## 阅读工具

直接使用 Cosmic PDF 打开 PDF 链接和网页内嵌文档，或选择本地文件。支持文字查找、页面和目录导航、缩放、向左旋转、全屏、打印和下载原文件。也可切换回 Chrome 阅读器。

## 本地 OCR

支持英文、简体中文和繁体中文扫描件，也能识别中英混合内容。每页识别完成后，即可直接在页面上选择、复制文字。可按需识别，也可独立于 AI 解释开启当前扫描页自动识别。OCR 不上传或修改 PDF。

## AI 解释

选取一段文字，解释其含义或继续提问。选择**内置 AI（API）**，使用您自己的 Google Gemini、OpenAI 或 Claude API 密钥在 Cosmic PDF 中查看回答；也可选择**自带 AI（订阅账号）**，直接使用已有的 ChatGPT 或 Claude 网页账号，无需 API 密钥。支持时在 PDF 旁分屏打开网站，否则打开相邻标签页。星芒开关控制选中文字时是否显示解释按钮，仅传递您选择的文字和该选项开启时的附近内容。

## 自定义

设置页提供外观、工具栏布局、1×–6× 显示清晰度、可选锐化、初始缩放、页面间距、缩略图、文档链接、外部链接捕获和 OCR 选项。界面支持英文和简体中文。

## 安装

需要 Chrome 128 或更高版本。

1. 打开 `chrome://extensions`，开启“开发者模式”。
2. 点击“加载已解压的扩展程序”，选择本仓库的 `extension` 目录。
3. 可将 **Cosmic PDF** 固定在工具栏，以便打开本地文件。阅读器和扩展选项菜单均可进入设置页。

若希望自动接管 `file://` PDF 链接，请在 Chrome 扩展详情中开启“允许访问文件网址”，然后重新打开 PDF。选择文件或拖放文件无需该权限。

自动打开支持普通 HTTP(S) PDF 响应（含网页内嵌阅读器），以及已授权的本地 PDF 链接。暂不自动替换通过 POST 生成的文档或不透明的 blob 链接。标记为附件的文件仍正常下载。部分需要登录或一次性链接的文件可能需要使用 Chrome 阅读器或本地副本。本阅读器的文件安全读取上限为 64 MB。

## 隐私与安全

PDF 阅读和 OCR 均在本机进行。文档、识别结果和内置 AI 对话仅保留在当前阅读器中，关闭后丢弃；请求 AI 解释时，所选文字会发送至您选择的服务。网页方式的对话留在 AI 网站，预填问题可能出现在浏览器历史记录或同步记录中。偏好设置和加密 API 密钥保存在本地，可在设置中按服务查看、测试、替换或删除密钥。AI 的可用性、费用和数据处理遵循所选服务的条款。PDF 脚本、表单执行、编辑和远程文档资源均被禁用，不改变原文件。任何解析器都无法保证抵御所有畸形文件，请保持 Chrome 和扩展更新。

## 开发

运行 `npm test` 和 `npm run check`。参见[技术文档](docs/TECHNICAL.md)、[浏览器验证说明](docs/QA.md)，以及随扩展打包的 [`extension/vendor/`](extension/vendor/) 中的第三方许可证和声明。

## 发布下载包

[安装包下载](https://cpdf.songming.org/downloads/cosmic-pdf.zip) · [完整源码下载](https://cpdf.songming.org/downloads/cosmic-pdf-source.zip)。解压后，在 Chrome「加载已解压的扩展程序」中选择 `extension` 文件夹。

发布更新前运行 `python3 scripts/build-downloads.py`，将重新生成的 `downloads/` 文件随版本一并提交。
