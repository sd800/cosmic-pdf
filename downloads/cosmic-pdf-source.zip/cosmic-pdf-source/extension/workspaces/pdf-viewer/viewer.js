import { isViewerHost } from './host-origin.js';
import { createAppearanceMenu } from './appearance-menu.js';
import { isAppearanceMode } from '../../core/appearance.js';
import { createAiReader } from './ai-reader.js';
import { bindPdfSelection } from './selection.js';
import { showReaderDialog } from './dialog.js';
import { createPdfWorker } from './worker.js';
import { createOcr } from './ocr.js';
import { createDarkPaperGuard } from './dark-paper.js';
import { renderedPaperBackground } from './paper-background.js';
import { installPagePrefetch } from './prefetch.js';
import { normalizeSettings, toolbarMode as getToolbarMode } from '../../core/settings.js';
import * as pdfjs from '../../vendor/pdfjs/pdf.min.mjs';
import { PDFViewer, EventBus, PDFLinkService, PDFFindController, RenderingStates } from '../../vendor/pdfjs/pdf_viewer.mjs';
import { labels } from './labels.js';
import { setReaderIcon, setReaderIcons } from './icons.js';
import { createToolbarMenu } from './toolbar-menu.js';
import { normalizePdfSampling } from '../../core/pdf-sampling.js';
import { pdfPageNumber, pdfOpenPage, PDF_LIMITS, pdfDetailCanvasPixels, pdfOptions, pdfScale, parsePdfZoom, stepPdfScale, rotateLeft, safePdfLink } from './model.js';

const $ = id => document.getElementById(id);
let port, task, pdf, viewer, pdfWorker, parseTimer, destroyed = false, text = {...labels['en-US']}, fullscreenActive = false;
const lifetime = new AbortController(), signal = lifetime.signal;
const eventBus = new EventBus(), viewport = $('viewport');
let workerReady;
let requestedPage = 1, pagesReady = false;
let firstPageReady = false, themeDark = false, darkPaper;
let aiReader;
const readingSelection = bindPdfSelection({ pages: $('pages'), signal, onClear: () => aiReader?.dismissSelection() });
let themeMode = 'auto', appearanceMenu;
let customZoomScale = null, toolbarMenu, externalLinksCapture, linkRequest = 0;
let thumbnailObserver, thumbnailTask, thumbnailBusy = false, thumbnailGeneration = 0, outlineLoaded = false;
const nearThumbnails = new Set(), thumbnailCache = new Map();
let sharpening = false, settings, ocr, documentFilename, documentUrl = '', documentBytes = 0, properties;
let showAnnotations = true;
const annotationMode = () => showAnnotations ? pdfjs.AnnotationMode.ENABLE : pdfjs.AnnotationMode.DISABLE;
let zoomFrame = 0, wheelFactor = 1, wheelOrigin, passwordCancelled = false;
const emit = type => port?.postMessage({ type });
let taskBusy = false, renderBusy = false, aiBusy = false, renderProgressTimer = 0, visiblePageViews = [];
function paintProgress() {
  const busy = taskBusy || renderBusy || aiBusy;
  $('progress').hidden = !busy; $('workspace').setAttribute('aria-busy', String(busy));
}
function status(key, loading = false) { $('status').textContent = key === 'loading' ? '' : text[key] || ''; taskBusy = loading; paintProgress(); }
function syncRenderProgress() {
  const pending = () => !destroyed && firstPageReady && !document.hidden &&
    visiblePageViews.some(view => view.renderingState !== RenderingStates.FINISHED);
  if (!pending()) {
    clearTimeout(renderProgressTimer); renderProgressTimer = 0;
    if (renderBusy) { renderBusy = false; paintProgress(); }
  } else if (!renderBusy && !renderProgressTimer) {
    // One delayed notification, no polling or extra page/geometry scans.
    renderProgressTimer = setTimeout(() => {
      renderProgressTimer = 0;
      if (pending()) { renderBusy = true; paintProgress(); }
    }, 200);
  }
}
function theme(dark, mode = themeMode) {
  if (isAppearanceMode(mode)) themeMode = mode;
  themeDark = !!dark;
  document.documentElement.dataset.dark = String(themeDark); document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
  if (themeDark) for (const view of viewer?.getCachedPageViews() || []) updateDarkPaper(view);
  setReaderIcon($('theme'), dark ? 'sun' : 'moon');
  $('theme').title = text.theme; $('theme').setAttribute('aria-label', text.theme);
  appearanceMenu?.refresh();
}
function toolbarPreferences(toolbar) {
  document.documentElement.dataset.toolbar = toolbar;
  const header = document.querySelector('header'), file = header.querySelector('.file'), leading = $('leading-actions');
  if (toolbar === 'both') header.insertBefore(leading, header.querySelector('nav'));
  else header.querySelector('.leading-cluster').prepend(leading);
  if (toolbar === 'filename') header.querySelector('.leading-cluster').append(file);
  else header.insertBefore(file, header.querySelector('.actions'));
  file.hidden = toolbar === 'branding' || toolbar === 'none';
  header.querySelector('.identity').hidden = toolbar === 'filename' || toolbar === 'none';
}
function setFilename(value = $('filename').textContent) {
  $('filename').textContent = String(value || 'PDF').slice(0, 1024);
  $('filename').title = `${$('filename').textContent} — ${text.properties}`;
  $('filename').setAttribute('aria-label', $('filename').title);
}
function localize(locale) {
  const previous = {...text};
  Object.assign(text, labels[locale] || labels['en-US']);
  document.documentElement.lang = locale === 'zh-CN' ? locale : 'en-US';
  for (const node of document.querySelectorAll('[data-text]')) node.textContent = text[node.dataset.text];
  for (const node of document.querySelectorAll('[data-label]')) { node.title = text[node.dataset.label]; node.setAttribute('aria-label', node.title); }
  for (const id of ['status','password-message','matches']) {
    const key = Object.keys(previous).find(key => previous[key] === $(id).textContent);
    if (key) $(id).textContent = text[key];
  }
  theme(themeDark); setFilename();
  $('fullscreen').title = text[fullscreenActive ? 'exitFullscreen' : 'fullscreen'];
  $('fullscreen').setAttribute('aria-label', $('fullscreen').title);
  aiReader?.localize();
  ocr?.setInterface(settings.ocrAction);
  toolbarMenu?.refreshLabels();
  if(externalLinksCapture)void externalLinksCapture.then(dialog=>dialog.setLocale(document.documentElement.lang)).catch(()=>{});
  if(properties)void properties.then(dialog => { if (!destroyed) dialog.setInterface(document.documentElement.lang, settings.propertyDateFormat); });
}
function setDarkPaper(enabled) {
  settings.preserveDarkPaper = enabled === true;
  document.documentElement.dataset.preserveDarkPaper = String(settings.preserveDarkPaper);
  if (themeDark && settings.preserveDarkPaper) for (const view of viewer?.getCachedPageViews() || []) updateDarkPaper(view);
}
function updateDarkPaper(view, failed = false) {
  if (!darkPaper || !view || ((!themeDark || !settings.preserveDarkPaper) && !failed)) return;
  // A detail canvas is only a crop; a partial base render can miss white areas.
  if (!failed && view.renderingState !== RenderingStates.FINISHED) return;
  const result = failed ? darkPaper.reject(view.id) : darkPaper.decide(view.id, view.canvas, context => renderedPaperBackground(view.pdfPage, pdfjs.OPS, context, view.viewport.rotation));
  view.div.toggleAttribute('data-original-dark', result === 2);
  view.div.setAttribute('data-dark-checked', '');
  $('thumbnails').children[view.id - 1]?.toggleAttribute('data-original-dark', result === 2);
}
function updateCanvasSharpening(view, transformed = false) {
  const canvas = view?.canvas;
  if (!canvas) return;
  // Only sharpen bounded base surfaces already at the requested density.
  // Stretched high-zoom previews must not allocate oversized filter surfaces.
  const density = view.getRenderPixelRatio();
  canvas.classList.toggle('pdf-sharpen', sharpening && !transformed && view.renderingState === RenderingStates.FINISHED &&
    canvas.width / view.viewport.width >= density * .98 && canvas.height / view.viewport.height >= density * .98);
}
function setSharpening(enabled) {
  const next = enabled === true;
  if (sharpening === next) return;
  sharpening = next;
  document.documentElement.dataset.sharpen = String(next);
  // CSS removal drops the extra compositor filter; reuse the existing PDF
  // canvases without parsing, rasterizing or allocating replacement surfaces.
  for (const view of viewer?.getCachedPageViews() || []) updateCanvasSharpening(view);
}
function click(id, callback) { $(id).addEventListener('click', callback, { signal }); }
function destroy() {
  if (destroyed) return; destroyed = true; lifetime.abort(); cancelAnimationFrame(zoomFrame); clearTimeout(parseTimer); clearTimeout(renderProgressTimer); visiblePageViews = [];
  aiReader?.destroy();
  ocr?.destroy(); darkPaper?.destroy(); thumbnailGeneration++; thumbnailObserver?.disconnect(); thumbnailTask?.cancel();
  viewer?.setDocument(null); void task?.destroy().catch(() => {});
  pdfWorker?.destroy(); port?.close();
}
window.addEventListener('pagehide', destroy, { once: true });
window.addEventListener('message', event => {
  if (destroyed || event.source !== parent || !isViewerHost(event.origin, import.meta.url) || port || event.data?.type !== 'CP_PDF_INIT' || event.ports.length !== 1) return;
  // Start the parser during transfer, but only after our host has initialized
  // this sandbox. Direct webpage embeds cannot allocate a parser worker.
  workerReady = createPdfWorker(pdfjs, signal).then(worker => { pdfWorker = worker; return worker; });
  void workerReady.catch(() => {});
  const input = event.data;
  documentUrl = typeof input.documentUrl === 'string' ? input.documentUrl : '';
  requestedPage = pdfOpenPage(documentUrl, 99_999_999);
  settings = normalizeSettings(input.settings);
  setDarkPaper(settings.preserveDarkPaper);
  toolbarPreferences(getToolbarMode(settings));
  document.documentElement.style.setProperty('--page-gap', settings.gap + 'px');
  document.documentElement.style.setProperty('--dark-strength',settings.darkStrength);
  document.documentElement.dataset.motion = String(settings.motion);
  port = event.ports[0];
  let opened = false;
  for (const control of document.querySelectorAll('header nav button:not(#fullscreen), header nav input, header nav select, #sidebar-toggle, #print, #download, #properties, #filename')) control.disabled = true;
  $('native').disabled = input.canUseNative !== true;
  port.onmessage = ({ data }) => {
    if (destroyed) return;
    if (data?.type === 'document') {
      if (opened || !(data.bytes instanceof ArrayBuffer) || !data.bytes.byteLength || data.bytes.byteLength > PDF_LIMITS.bytes) return;
      opened = true; documentBytes = data.bytes.byteLength; documentFilename = String(data.filename || 'PDF').slice(0, 1024);
      setFilename(data.filename);
      $('download').disabled = $('native').disabled = false; toolbarMenu?.refresh();
      void open(data.bytes, normalizePdfSampling(input.sampling)).catch(() => {
        clearTimeout(parseTimer);
        if (!destroyed && !passwordCancelled) { status('failed'); emit('error'); void task?.destroy().catch(() => {}); pdfWorker?.destroy(); }
      });
    }
    else if (data?.type === 'ai-preferences') {
      const next=normalizeSettings(data.preferences);settings={...settings,aiEnabled:next.aiEnabled,aiMode:next.aiMode,aiWebsite:next.aiWebsite,aiProvider:next.aiProvider,aiLanguage:next.aiLanguage,aiIncludeContext:next.aiIncludeContext};aiReader?.preferences(settings);ocr?.refreshAutomatic();
    }
    else if (data?.type === 'ai-status') { aiReader?.status(data.state); ocr?.refreshAutomatic(); }
    else if (data?.type === 'clear-selection') readingSelection.clear();
    else if (data?.type === 'page-destination') {
      if (Number.isSafeInteger(data.page) && data.page > 0 && data.page <= 99_999_999) {
        requestedPage = data.page;
        if (pagesReady) viewer.scrollPageIntoView({pageNumber:Math.min(pdf.numPages,requestedPage)});
      }
    }
    else if (data?.type === 'ai-event') aiReader?.event(data.event);
    else if (data?.type === 'theme') theme(data.dark, data.themeMode);
    else if (data?.type === 'toolbar') {
      const next = normalizeSettings(data.toolbar);
      settings = { ...settings, showFilename: next.showFilename, showBranding: next.showBranding, toolbarHidden: next.toolbarHidden };
      toolbarPreferences(getToolbarMode(settings)); toolbarMenu?.update(settings);
    }
    else if (data?.type === 'dark-paper') setDarkPaper(data.enabled);
    else if (data?.type === 'sharpening') setSharpening(data.enabled);
    else if (data?.type === 'host-error') { $('status').textContent = String(data.message || '').slice(0,1000); taskBusy = false; paintProgress(); }
    else if (data?.type === 'interface') {
      const next = normalizeSettings(data);
      settings = {...settings, propertyDateFormat:next.propertyDateFormat, ocrAction:next.ocrAction, automaticOcr:next.automaticOcr, useChromeFind:next.useChromeFind};
      setLinkCapture(next.captureLinks);
      localize(data.locale);
      ocr?.refreshAutomatic();
    }
    else if (data?.type === 'fullscreen-error') status('fullScreenFailed');
    else if (data?.type === 'fullscreen') {
      fullscreenActive = !!data.active;
      setReaderIcon($('fullscreen'), data.active ? 'fullscreen-exit' : 'fullscreen');
      $('fullscreen').title = text[data.active ? 'exitFullscreen' : 'fullscreen'];
      $('fullscreen').setAttribute('aria-label', $('fullscreen').title); toolbarMenu?.refresh();
    }
  };
  localize(input.locale);
  setFilename(input.filename);
  setSharpening(input.sharpening);
  theme(input.dark, input.themeMode); status('loading', true);
  setReaderIcons(document);
  aiReader=createAiReader({settings,post:message=>port?.postMessage(message),getPdf:()=>pdf,getLocale:()=>document.documentElement.lang,signal,onBusy:value=>{if(aiBusy!==value){aiBusy=value;paintProgress();}}});
  port.postMessage({type:'ai-refresh'});
  $('scale').value = settings.zoom.startsWith('page-') ? settings.zoom : String(Number(settings.zoom));
  $('scale-input').value = (Number(settings.zoom) > 0 ? Math.round(Number(settings.zoom) * 100) : 100) + '%';
  toolbarMenu = createToolbarMenu({ text, signal, onSettings: () => emit('settings'), onOcrPanel: () => ocr?.openPanel(), canHoldOcr: () => settings.ocrAction !== 'panel', onFit: value => { if (viewer) viewer.currentScaleValue = value; } });
  toolbarMenu.update(settings);
  appearanceMenu = createAppearanceMenu({text,signal,getMode:()=>themeMode,onChoose:mode=>port?.postMessage({type:'theme',mode})});
  // Keep form navigation forbidden by the sandbox, including method=dialog.
  // These controls only validate local input and close the local dialog.
  for (const form of document.querySelectorAll('dialog form')) {
    form.addEventListener('submit', event => event.preventDefault(), { signal });
    for (const button of form.querySelectorAll('button')) {
      button.type = 'button';
      button.onclick = () => { if (button.value === 'cancel' || form.reportValidity()) form.closest('dialog').close(button.value); };
    }
    form.addEventListener('keydown', event => {
      if (event.key === 'Enter') { event.preventDefault(); form.querySelector('button:not([value=cancel])').click(); }
    }, { signal });
  }
  click('download', () => emit('download')); click('theme', () => emit('theme'));
  click('fullscreen', () => emit('fullscreen')); click('native', () => emit('native'));
  emit('shell-ready');
}, { signal });

async function open(bytes, sampling) {
  const worker = await workerReady;
  if (destroyed) return;
  task = pdfjs.getDocument({ ...pdfOptions(new Uint8Array(bytes), new URL('../../vendor/pdfjs/', import.meta.url).href), worker });
  const armParseDeadline = () => {
    clearTimeout(parseTimer);
    parseTimer = setTimeout(() => { if (!destroyed) { status('failed'); emit('error'); void task.destroy().catch(() => {}); pdfWorker?.destroy(); } }, 30000);
  };
  armParseDeadline();
  task.onPassword = (accept, reason) => {
    if (destroyed) return;
    clearTimeout(parseTimer);
    emit('password'); status('');
    $('password-message').textContent = text[reason === pdfjs.PasswordResponses.INCORRECT_PASSWORD ? 'passwordWrong' : 'passwordNeeded'];
    $('password').value = ''; showReaderDialog($('password-dialog'), $('password'));
    $('password-dialog').onclose = () => {
      if (destroyed) return;
      if ($('password-dialog').returnValue === 'open') { status('loading', true); armParseDeadline(); accept($('password').value); $('password').value = ''; }
      else { passwordCancelled = true; status('cancelled'); void task.destroy().catch(() => {}); pdfWorker?.destroy(); }
    };
  };
  pdf = await task.promise;
  clearTimeout(parseTimer);
  if (destroyed) return;
  if (pdf.numPages > PDF_LIMITS.pages) { await task.destroy(); throw Error('PDF page budget'); }
  darkPaper = createDarkPaperGuard(pdf.numPages, settings.darkStrength);
  emit('parsed'); $('properties').disabled = $('filename').disabled = false;
  const links = new PDFLinkService({ eventBus });
  // Paint existing annotation/widget appearances into the canvas only.
  // No PDF.js HTML annotation/form/editor/scripting layer is instantiated.
  const find = new PDFFindController({ eventBus, linkService: links });
  viewer = new PDFViewer({ container: viewport, viewer: $('pages'), eventBus, linkService: links, findController: find,
    annotationMode: pdfjs.AnnotationMode.DISABLE, getAnnotationMode: annotationMode, annotationEditorMode: pdfjs.AnnotationEditorType.DISABLE,
    enableAutoLinking: false, enablePermissions: true, scriptingManager: null, textLayerMode: 1,
    // The fixed pixel/dimension limits already bound memory. A second
    // screen-relative cap makes ordinary Retina pages render as tiny canvases.
    getRenderPixelRatio: () => sampling,
    maxCanvasPixels: Math.min(PDF_LIMITS.canvasPixels, pdfDetailCanvasPixels(sampling)), maxDetailCanvasPixels: pdfDetailCanvasPixels(sampling),
    maxCanvasDim: 8192, capCanvasAreaFactor: -1,
    enableDetailCanvas: true, enableOptimizedPartialRendering: true, minDurationToUpdateCanvas: 160,
    imagesRightClickMinSize: -1, abortSignal: signal });
  links.setViewer(viewer); links.setDocument(pdf);
  installPagePrefetch(viewer);
  const render = viewer.renderingQueue.renderHighestPriority.bind(viewer.renderingQueue);
  viewer.renderingQueue.renderHighestPriority = (...args) => {
    // Reuse the renderer's existing visible set; do not inspect every page on scroll.
    if (args[0]?.views) visiblePageViews = args[0].views.filter(item=>item.percent>0).map(item=>item.view);
    if (!destroyed && !document.hidden) render(...args);
    syncRenderProgress();
  };
  document.addEventListener('visibilitychange', () => {
    cancelThumbnails();
    if (document.hidden) viewer.cleanup(); else { viewer.update(); void drawThumbnails(); }
    syncRenderProgress();
  }, { signal });
  eventBus.on('pagesinit', () => {
    const initialPage = Math.min(pdf.numPages, requestedPage); pagesReady = true;
    for (const control of document.querySelectorAll('header nav button, header nav input, header nav select, #sidebar-toggle')) control.disabled = false;
    viewer.currentScaleValue = settings.zoom;
    // Setting the initial scale aligns the first paper edge with the viewport.
    // Restore its top gutter once at initialization, never during later reading.
    if (initialPage === 1) viewport.scrollTop = 0;
    else viewer.scrollPageIntoView({pageNumber:initialPage});
    viewer.update();
    $('count').textContent = String(pdf.numPages); $('page').max = pdf.numPages; $('page').parentElement.style.setProperty('--page-digits', Math.max(2, String(pdf.numPages).length));
    $('page').value = initialPage; $('previous').disabled = initialPage === 1; $('next').disabled = initialPage === pdf.numPages; $('print').disabled = !viewer.printingAllowed;
    if (settings.sidebar) $('sidebar').hidden = false; toolbarMenu.refresh();
  }, { signal });
  eventBus.on('pagechanging', ({ pageNumber }) => {
    $('page').value = pageNumber; $('previous').disabled = pageNumber === 1; $('next').disabled = pageNumber === pdf.numPages;
    toolbarMenu.refresh();
    for (const node of $('thumbnails').children) node.setAttribute('aria-current', String(Number(node.dataset.page) === pageNumber));
  }, { signal });
  eventBus.on('pagerendered', ({ pageNumber, cssTransform, isDetailView, error }) => {
    if (!isDetailView && !cssTransform) updateDarkPaper(viewer.getPageView(pageNumber - 1), !!error);
    // A user may scroll away from page one before its render finishes.
    if (!firstPageReady) {
      firstPageReady = true; status(''); emit('ready');
      // Let the first page reach the screen before optional thumbnail work.
      if (!$('sidebar').hidden) requestAnimationFrame(() => { if (!destroyed && !$('thumbnails').children.length) createThumbnails(); });
    }
    if (error) status('pageError');
    if (sharpening) updateCanvasSharpening(viewer.getPageView(pageNumber - 1), cssTransform || error);
    if (!cssTransform && !destroyed) void renderLinks(pageNumber, links).catch(() => {});
    syncRenderProgress();
  }, { signal });
  eventBus.on('scalechanging', ({ scale, presetValue }) => {
    if (sharpening) for (const view of viewer.getCachedPageViews()) view.canvas?.classList.remove('pdf-sharpen');
    const preset = presetValue || String(scale);
    const custom = $('custom-scale'), select = $('scale');
    select.value = preset;
    if (select.value && preset !== 'custom') {
      custom.hidden = true; customZoomScale = null;
    } else {
      custom.textContent = Math.round(scale * 100) + '%'; custom.hidden = false;
      select.value = 'custom'; customZoomScale = scale;
    }
    $('scale-input').value = Math.round(scale * 100) + '%';
    $('zoom-in').disabled = scale >= 5; $('zoom-out').disabled = scale <= .25; toolbarMenu.refresh();
  }, { signal });
  eventBus.on('updatefindmatchescount', ({ matchesCount }) => { $('matches').textContent = `${matchesCount.current} / ${matchesCount.total}`; }, { signal });
  eventBus.on('updatefindcontrolstate', ({ state, matchesCount }) => {
    $('matches').textContent = state === 3 ? text.searching : state === 1 ? text.noMatches : `${matchesCount?.current || 0} / ${matchesCount?.total || 0}`;
  }, { signal });
  ocr = createOcr({ pdf, viewer, eventBus, settings, text, signal, canAutoRecognize: () => settings.automaticOcr || aiReader?.canExplain() === true });
  viewer.setDocument(pdf);
  click('previous', () => viewer.previousPage()); click('next', () => viewer.nextPage());
  $('page').onchange = () => { viewer.currentPageNumber = pdfPageNumber($('page').value, pdf.numPages, viewer.currentPageNumber); $('page').value = viewer.currentPageNumber; };
  function zoomTo(scale, origin) { viewer.updateScale({ scaleFactor: pdfScale(scale) / viewer.currentScale, drawingDelay: 180, origin }); }
  click('zoom-in', () => zoomTo(stepPdfScale(viewer.currentScale, 1))); click('zoom-out', () => zoomTo(stepPdfScale(viewer.currentScale, -1)));
  // Keep high-frequency zoom updates small. Order the transient option only
  // when the native menu is about to open, for both pointer and keyboard use.
  function locateCustomZoom() {
    if (customZoomScale === null) return;
    const select = $('scale'), custom = $('custom-scale');
    const upper = [...select.options].find(option => option !== custom && Number(option.value) > customZoomScale);
    select.insertBefore(custom, upper || null); select.value = 'custom'; customZoomScale = null;
  }
  $('scale').addEventListener('pointerdown', locateCustomZoom, { signal });
  $('scale').addEventListener('keydown', event => {
    if (['ArrowDown', 'ArrowUp', ' ', 'Enter', 'Home', 'End'].includes(event.key)) locateCustomZoom();
  }, { signal });
  $('scale').onchange = () => { const value = $('scale').value; if (value === 'custom') return; if (value.startsWith('page-')) viewer.currentScaleValue = value; else zoomTo(Number(value)); };
  function resetZoomInput() { $('scale-input').value = Math.round(viewer.currentScale * 100) + '%'; }
  function commitZoomInput() {
    const value = parsePdfZoom($('scale-input').value);
    if (value !== null && Math.abs(value - viewer.currentScale) > .00001) zoomTo(value);
    resetZoomInput();
  }
  $('scale-input').addEventListener('blur', commitZoomInput, { signal });
  $('scale-input').addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); commitZoomInput(); $('scale-input').blur(); }
    else if (event.key === 'Escape') { event.preventDefault(); resetZoomInput(); $('scale-input').blur(); }
  }, { signal });
  click('rotate', () => {
    const page = viewer.currentPageNumber;
    viewer.pagesRotation = rotateLeft(viewer.pagesRotation);
    // PDFViewer leaves scroll repositioning to its host after rotation.
    viewer.currentPageNumber = page;
    clearThumbnails(); void drawThumbnails();
  });
  const resize = new ResizeObserver(() => { if (!destroyed && ['page-fit', 'page-width'].includes(viewer.currentScaleValue)) viewer.currentScaleValue = viewer.currentScaleValue; });
  resize.observe(viewport); signal.addEventListener('abort', () => resize.disconnect(), { once: true });
  viewport.addEventListener('wheel', event => {
    if (!event.ctrlKey && !event.metaKey) return; event.preventDefault();
    wheelFactor *= Math.exp(-Math.max(-100, Math.min(100, event.deltaY)) * .004); wheelOrigin = [event.clientX, event.clientY];
    if (!zoomFrame) zoomFrame = requestAnimationFrame(() => { zoomFrame = 0; zoomTo(viewer.currentScale * wheelFactor, wheelOrigin); wheelFactor = 1; });
  }, { passive: false, signal });
  function openFind() { $('findbar').hidden = false; $('query').focus(); $('query').select(); }
  function closeFind() { $('findbar').hidden = true; eventBus.dispatch('findbarclose', { source: window }); viewport.focus(); }
  function search(again = false, previous = false) {
    eventBus.dispatch('find', { source: window, type: again ? 'again' : '', query: $('query').value, caseSensitive: $('match-case').checked,
      entireWord: false, highlightAll: true, findPrevious: previous, matchDiacritics: false });
  }
  click('search-toggle', openFind); click('find-close', closeFind); click('find-next', () => search(true)); click('find-previous', () => search(true, true));
  $('query').oninput = () => search(); $('match-case').onchange = () => search();
  $('query').onkeydown = event => { if (event.key === 'Enter') { event.preventDefault(); search(true, event.shiftKey); } };
  window.addEventListener('keydown', event => {
    if (event.defaultPrevented || event.isComposing || document.querySelector('dialog[open]')) return;
    if (event.altKey) return; // Leave browser history shortcuts to Chrome.
    const modifier = event.ctrlKey || event.metaKey, editable = /INPUT|SELECT|TEXTAREA/.test(event.target.tagName);
    if (modifier && event.key.toLowerCase() === 'f') {
      // Native Find belongs to Chrome: never simulate or cancel its shortcut.
      if (settings.useChromeFind) { if (!$('findbar').hidden) closeFind(); return; }
      event.preventDefault(); openFind();
    }
    else if (modifier && event.key.toLowerCase() === 'p') { event.preventDefault(); openPrint(); }
    else if (modifier && event.key.toLowerCase() === 's') { event.preventDefault(); emit('download'); }
    else if (modifier && ['+', '=', '-', '0'].includes(event.key)) { event.preventDefault(); zoomTo(event.key === '0' ? 1 : stepPdfScale(viewer.currentScale, event.key === '-' ? -1 : 1)); }
    else if (event.key === 'Escape' && !$('findbar').hidden) closeFind();
    else if (!editable && !modifier && !event.shiftKey && event.key === 'ArrowLeft') { event.preventDefault(); viewer.previousPage(); }
    else if (!editable && !modifier && !event.shiftKey && event.key === 'ArrowRight') { event.preventDefault(); viewer.nextPage(); }
    else if (!editable && !modifier && !event.shiftKey && event.key === 'Home') { event.preventDefault(); viewer.currentPageNumber = 1; }
    else if (!editable && !modifier && !event.shiftKey && event.key === 'End') { event.preventDefault(); viewer.currentPageNumber = pdf.numPages; }
  }, { signal });
  click('sidebar-toggle', () => {
    $('sidebar').hidden = !$('sidebar').hidden;
    if (firstPageReady && !$('sidebar').hidden && !$('thumbnails').children.length) createThumbnails();
    if ($('sidebar').hidden) cancelThumbnails(); else void drawThumbnails();
  });
  click('show-pages', () => { $('outline').hidden = true; $('thumbnails').hidden = false; void drawThumbnails(); });
  click('show-outline', () => { $('thumbnails').hidden = true; $('outline').hidden = false; cancelThumbnails(); void showOutline(links); });
  const openProperties = () => {
    // Import and read metadata only on demand; retain one small dialog model.
    properties ||= import('./properties.js').then(({ createProperties }) => destroyed ? null : createProperties({ pdf, viewer, filename: documentFilename, documentUrl, byteLength: documentBytes, locale: document.documentElement.lang, dateFormat: settings.propertyDateFormat, text, signal }));
    void properties.then(dialog => { if (!destroyed) return dialog.open(); }).catch(() => { if (!destroyed) status('propertiesUnavailable'); });
  };
  click('properties', openProperties); click('filename', openProperties);
  click('annotations', () => {
    if (destroyed) return;
    showAnnotations = !showAnnotations;
    $('annotations').setAttribute('aria-pressed', String(showAnnotations));
    // Invalidate only retained page views, not every page or the parsed document.
    for (const view of viewer.getCachedPageViews()) {
      view.recordedBBoxes = null;
      view.reset();
    }
    clearThumbnails(); viewer.update(); void drawThumbnails();
  });
  click('print', openPrint);
}

async function captureExternalLink(url,anchor) {
  const request=++linkRequest;
  externalLinksCapture ||= import('../../shared/external-links-capture/capture.js').then(({createExternalLinksCapture})=>createExternalLinksCapture({signal,locale:document.documentElement.lang}));
  try { const dialog=await externalLinksCapture;if(!destroyed&&settings.links&&linkNeedsCapture(url)&&anchor.isConnected&&request===linkRequest)dialog.show(url,anchor); } catch {}
}

// Protocol links are copy-only even when ordinary web-link capture is off.
function linkNeedsCapture(url) { return settings.captureLinks || !/^https?:/i.test(url); }
function setLinkCapture(enabled) {
  settings.captureLinks = enabled === true;
  for (const link of document.querySelectorAll('.pdf-links a[data-external-link]')) link.href = linkNeedsCapture(link.dataset.externalLink) ? '#' : link.dataset.externalLink;
  if (!settings.captureLinks) {
    if(externalLinksCapture)void externalLinksCapture.then(dialog=>dialog.closeWeb()).catch(()=>{});
  }
}
function bindExternalLink(node, url) {
  node.dataset.externalLink = url; node.title = url;
  if (node.tagName === 'A') { node.href = linkNeedsCapture(url) ? '#' : url; node.target = '_blank'; node.rel = 'noopener noreferrer'; }
  const activate = event => {
    if (!event.isTrusted || !settings.links) { event.preventDefault(); return; }
    if (event.type !== 'click' && event.button !== 1) return;
    if (linkNeedsCapture(url)) { event.preventDefault(); event.stopPropagation(); void captureExternalLink(url,node); }
    else if (node.tagName !== 'A') { event.preventDefault(); window.open(url,'_blank','noopener,noreferrer'); }
  };
  node.addEventListener('click',activate); node.addEventListener('auxclick',activate);
}

async function renderLinks(number, linkService) {
  const pageView = viewer.getPageView(number - 1), viewport = pageView?.viewport;
  if (!pageView?.pdfPage || !viewport || destroyed) return;
  const annotations = await pageView.pdfPage.getAnnotations({ intent: 'display' }).catch(() => []);
  if (destroyed || pageView.viewport !== viewport || !pageView.canvas) return;
  pageView.div.querySelector('.pdf-links')?.remove();
  if (annotations.some(item => item && !['Link','Popup'].includes(item.subtype))) $('annotations').hidden = false;
  if (!settings.links) return;
  const layer = document.createElement('div'); layer.className = 'pdf-links';
  for (const item of annotations.slice(0, 1000)) {
    if (item.subtype !== 'Link' || item.actions || !Array.isArray(item.rect) || item.rect.length !== 4 || !item.rect.every(Number.isFinite)) continue;
    const url = safePdfLink(item.url || item.unsafeUrl); if (!url && !item.dest) continue;
    const rect = [...viewport.convertToViewportPoint(item.rect[0], item.rect[1]), ...viewport.convertToViewportPoint(item.rect[2], item.rect[3])];
    if (!rect.every(Number.isFinite)) continue;
    const link = document.createElement('a');
    if (url) {
      // Capture mode carries no external href, including for modifier clicks.
      bindExternalLink(link,url);
    }
    else { link.href = '#'; link.onclick = e => { e.preventDefault(); void linkService.goToDestination(item.dest).catch(() => {}); }; link.title = text.page; }
    link.style.cssText = `left:${Math.min(rect[0],rect[2])/viewport.width*100}%;top:${Math.min(rect[1],rect[3])/viewport.height*100}%;width:${Math.abs(rect[2]-rect[0])/viewport.width*100}%;height:${Math.abs(rect[3]-rect[1])/viewport.height*100}%`;
    link.setAttribute('aria-label', link.title); layer.append(link);
  }
  pageView.div.append(layer);
}
function createThumbnails() {
  const fragment = document.createDocumentFragment();
  for (let i = 1; i <= pdf.numPages; i++) { const button = document.createElement('button'); button.className = 'thumbnail'; button.dataset.page = i; button.toggleAttribute('data-original-dark', darkPaper.get(i) === 2); button.textContent = String(i); button.title = text.page + ' ' + i; button.onclick = () => { viewer.currentPageNumber = i; }; fragment.append(button); }
  $('thumbnails').append(fragment);
  thumbnailObserver = new IntersectionObserver(entries => { for (const entry of entries) { if (entry.isIntersecting) nearThumbnails.add(entry.target); else nearThumbnails.delete(entry.target); } void drawThumbnails(); }, { root: $('sidebar'), rootMargin: '160px' });
  for (const node of $('thumbnails').children) thumbnailObserver.observe(node);
}
function clearThumbnails() {
  cancelThumbnails();
  for (const [node, canvas] of thumbnailCache) { canvas.width = canvas.height = 0; node.replaceChildren(String(node.dataset.page)); }
  thumbnailCache.clear();
}
function cancelThumbnails() { thumbnailGeneration++; thumbnailTask?.cancel(); }
const thumbnailsVisible = () => !destroyed && !document.hidden && !$('sidebar').hidden && !$('thumbnails').hidden;
async function drawThumbnails() {
  if (thumbnailBusy || !thumbnailsVisible()) return;
  const generation = thumbnailGeneration; thumbnailBusy = true;
  const current = () => generation === thumbnailGeneration && thumbnailsVisible();
  try {
    for (const node of nearThumbnails) {
      if (!current()) break;
      if (thumbnailCache.has(node)) continue;
      const page = await pdf.getPage(Number(node.dataset.page));
      if (!current()) break;
      if (!nearThumbnails.has(node)) continue;
      const base = page.getViewport({ scale: 1, rotation: (page.rotate + viewer.pagesRotation) % 360 });
      const viewport = page.getViewport({ scale: Math.min(144 / base.width, 145 / base.height), rotation: base.rotation });
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
      const canvas = document.createElement('canvas'); canvas.width = Math.ceil(viewport.width * pixelRatio); canvas.height = Math.ceil(viewport.height * pixelRatio);
      canvas.style.width = viewport.width + 'px'; canvas.style.height = viewport.height + 'px';
      try {
        thumbnailTask = page.render({ canvasContext: canvas.getContext('2d'), viewport,
          transform: [pixelRatio, 0, 0, pixelRatio, 0, 0], annotationMode: annotationMode() });
        await thumbnailTask.promise;
        if (!current()) break;
        if (!nearThumbnails.has(node)) continue;
        eventBus.dispatch('thumbnailrendered', { pageNumber: Number(node.dataset.page), pdfPage: page });
        node.replaceChildren(canvas, String(node.dataset.page)); thumbnailCache.set(node, canvas);
      } finally {
        thumbnailTask = null;
        // Cancellation also releases a canvas that never reached the cache.
        if (!thumbnailCache.has(node)) canvas.width = canvas.height = 0;
      }
      // Thumbnails are tiny and only requested when their sidebar region is near.
      for (const [old, image] of thumbnailCache) { if (thumbnailCache.size <= 24) break; if (nearThumbnails.has(old)) continue; image.width = image.height = 0; old.replaceChildren(String(old.dataset.page)); thumbnailCache.delete(old); }
    }
  } catch { /* A close, rotation or tab hide cancels only the optional thumbnails. */ }
  finally { thumbnailBusy = false; if (!destroyed && generation !== thumbnailGeneration) void drawThumbnails(); }
}
async function showOutline(links) {
  if (outlineLoaded) return; outlineLoaded = true;
  const items = await pdf.getOutline().catch(() => null); if (destroyed) return;
  if (!items?.length) { $('outline').textContent = text.noOutline; return; }
  let count = 0;
  function add(items, container, depth) {
    if (depth > 20) return;
    for (const item of items) { if (++count > 2000) break;
      const button = document.createElement('button'); button.textContent = String(item.title || text.page).slice(0, 512); button.style.paddingInlineStart = (8 + depth * 10) + 'px';
      const url = safePdfLink(item.url || item.unsafeUrl);
      if (url) { button.disabled = !settings.links; bindExternalLink(button,url); }
      else { button.disabled = !item.dest; button.onclick = () => void links.goToDestination(item.dest).catch(() => {}); }
      container.append(button);
      if (Array.isArray(item.items)) add(item.items, container, depth + 1);
    }
  }
  add(items, $('outline'), 0);
}
function openPrint() {
  if (!pdf || !viewer?.printingAllowed || destroyed) return;
  emit('print');
}
