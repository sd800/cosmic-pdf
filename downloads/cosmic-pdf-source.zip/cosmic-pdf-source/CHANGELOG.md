# Changelog

## 3.2.21 — 2026-10-20

- Preserve native text-selection shortcuts in the PDF reader.
- Improve local-file retries, thumbnail cancellation, print cleanup, theme backdrops, and protection against late updates after closing a reader.

## 3.2.20 — 2026-10-19

- Simplify the automatic text recognition setting description.

## 3.2.19 — 2026-10-19

- Support PDF opening within webpages and improve automatic takeover of downloaded/local PDFs, with Chrome-reader fallback.
- Add independent automatic current-page text recognition, including when Explain with AI is off.

## 3.2.18 — 2026-10-17

- Add a right-click appearance menu with Auto, Light and Dark choices, while keeping one-click switching.

## 3.2.17 — 2026-10-17

- Add a subtle divider below the AI model and status row, with matching model and status text sizes.

## 3.2.16 — 2026-10-17

- Add a local AI test model, toggled with 1 in Settings, with local streaming explanations and varied follow-up samples without API calls.
- Show code or table samples only when the follow-up requests their corresponding keywords.
- Keep test mode until manually turned off and mark it beside the Settings footer version.
- Simplify the AI service information in Settings.

## 3.2.15 — 2026-10-17

- Add a subtle divider above the AI follow-up area.

## 3.2.13 — 2026-10-17

- Format API explanations with common Markdown, including emphasis, headings, unindented lists, quotes, code and tables, without running HTML or loading external content.
- Tighten the space above Include nearby paragraphs.

## 3.2.12 — 2026-10-17

- Update the OpenAI API option to GPT-6 Luna for explanations and connection tests, preserving saved keys.

## 3.2.11 — 2026-10-17

- Align the concise completion status to the right of the AI model name and tighten nearby-context control spacing.

## 3.2.10 — 2026-10-17

- Start API explanations at the answer opening and follow-ups at the question, without automatic scrolling as replies stream.
- Make the brief AI accuracy reminder smaller with tighter line spacing.

## 3.2.9 — 2026-10-17

- Simplify the API explanation panel by removing the selected-passage preview and repeated provider notice, and shorten the smaller AI accuracy reminder.

## 3.2.8 — 2026-10-14

- Add direct installation and source downloads with reproducible local packaging.

## 3.2.7 — 2026-10-14

- Clean up repository maintenance files.

## 3.2.6 — 2026-10-13

- Enable Include nearby paragraphs by default while preserving existing saved preferences.

## 3.2.5 — 2026-10-13

- Update Google Gemini to Gemini 3.5 Flash-Lite for explanations and connection tests, with compatible request settings and existing saved keys preserved.

## 3.2.4 — 2026-10-13

- Redesign saved API keys as per-service rows with separate add/replace inputs, connection testing, Stop and individual deletion.
- Remove the bulk-delete button and clear the encryption root when the final saved key is deleted.
- Use compact non-streaming connection checks and distinguish key, project, model, quota, network and service errors without exposing provider details.

## 3.2.3 — 2026-10-13

- Clear PDF text selections when clicking elsewhere or changing focus, while preserving AI handoff and native copy gestures.
- Use recognized text for AI selections and nearby context without mixing in superseded native layers.
- Recognize textless current pages automatically when AI explanations are enabled, with bounded work and manual-recognition priority.

## 3.2.2 — 2026-10-13

- Remove the AI toolbar button’s background while retaining its neutral icon and off-state indicator.
- Make AI explanations adapt to keywords and longer selections without a fixed answer template, and phrase requests naturally from the reader’s perspective.

## 3.2.1 — 2026-10-13

- Add Bring Your Own AI via Subscription for ChatGPT and Claude, alongside Built-in AI via API, with radio choices and website mode selected by default.
- Open prefilled questions beside the PDF where Chrome supports automatic split view, with an adjacent-tab fallback and companion-tab reuse.
- Keep complete longer questions available for copying, and preserve existing API keys and preferences.

## 3.1.1 — 2026-10-13

- Add AI explanations for selected PDF and recognized text, with streamed answers, optional nearby context, and follow-up questions.
- Add a neutral sparkle switch in the reader and bilingual AI settings for Google Gemini, OpenAI, and Claude.
- Encrypt saved API keys on this device and provide confirmed deletion of one service’s key or all local keys.
- Separate untrusted document text from AI instructions and keep responses as inert text.

## 2.3.5 — 2026-09-29

- Show the original file URL below the file name in PDF Document properties.

## 2.3.3 — 2026-09-28

- Keep favicons and page branding in sync with the current extension icon, and show the installed version in Settings.

## 2.3.2 — 2026-09-28

- Highlight PDF dark-mode reading in the project introduction and extension description.

## 2.3.1 — 2026-09-25

- Keep settings consistent during rapid edits, language changes, and delayed storage updates.
- Strengthen recovery and cleanup when returning to Chrome's PDF reader.
- Improve PDF dialog cancellation, keyboard handling, and page-number validation.

## 2.2.2 — 2026-09-24

- Use a lighter blue extension icon to make Cosmic PDF easier to distinguish in the browser toolbar.

## 2.2.1 — 2026-09-24

- Improve recognized-text selection with continuous text rows, more consistent word spacing, and stable selection after zooming or rotating.

## 2.1.5 — 2026-09-23

- Prioritize newly recognized text after manual OCR and exclude the original text layer from browser Find and selection to avoid duplicate matches.
- Preserve original text when recognition returns no text, and restore it when results are cleared.

## 2.1.3 — 2026-09-23

- Reduce extension permissions while retaining automatic PDF opening and native-reader fallback.
- Save original PDFs through ordinary browser downloads, following Chrome’s download preferences without download-management access.

## 2.1.2 — 2026-09-23

- Extend external-link capture to application protocols, with an explicit Open application/Copy prompt. Email, telephone, and SMS links remain copy-only.
- Unify the underlying protocol parsing and confirmation components.

## 2.1.1 — 2026-09-23

- Avoid OCR WASM loading warnings without expanding network access.
- Place the product name above Settings and add matching tool icons and muted default-hidden notes to More actions choices.
- Fix PDF background-worker startup and whole-document copying in the isolated reader, and avoid cross-frame dialog autofocus.
- Remove page-interior loading symbols while scrolling; show a toolbar-divider progress line only when a visible page needs longer to render.
- Improve dark-paper recognition for dense text, colored callouts, and inset images using existing page-rendering evidence, while retaining conservative protection for white paper and light content panels.
- Hide Preserve dark-paper colors when Appearance is set to Light, retaining its saved preference when returning to Auto or Dark.
- Show Filename by default in Toolbar content, without changing existing saved choices.
- Keep only the newest Settings tab open, automatically closing earlier Settings tabs without affecting PDF readers.
- Return from Settings to Open a PDF in the same tab.
- Add a default-on Capture external links setting: document and outline web links show an Open/Copy prompt, with direct opening available when capture is off. Email/telephone/SMS links always offer copying only.

## 1.2.15 — 2026-09-23

- Add a default-on Preserve dark-paper colors setting to preserve original colors when strictly recognized black or gray paper would otherwise become brighter in dark mode, while keeping white-paper and mixed layouts under normal dark-mode processing. Reuse per-page decisions during zooming and rotation.

## 1.2.13 — 2026-09-23

- Slightly narrow the toolbar filename while preserving its size, ellipsis and document properties shortcut.

## 1.2.12 — 2026-09-23

- Open Document properties by clicking the regular-weight toolbar filename, and make properties dialogs more compact without reducing text size. Overflowing dialogs open at the top.
- Let More actions close when its button is clicked again, and keep hidden controls consistent across toolbar layouts.
- Use one light/dark appearance button in every layout and place Chrome reader in More actions by default.
- Keep Pages and outline at the left edge, alongside a sole branding or filename and on the second row when both are shown.

## 1.2.11 — 2026-09-23

- Make the reader’s Find button always open built-in search, independently of the Chrome Find shortcut preference, and remove shortcut banners.
- Highlight PDF search matches in orange and simplify the Chrome Find setting description.
- Abbreviate document-property time zones, keeping minutes only for non-whole-hour offsets.

## 1.2.10 — 2026-09-23

- Refine the Document properties information icon’s proportions and spacing.

## 1.2.9 — 2026-09-23

- Use a plain information icon for Document properties in the PDF reader.

## 1.2.8 — 2026-09-23

- Update the PDF reader’s Rotate left icon to a rounded square with a counterclockwise arrow, aligned with the other toolbar icons.

## 1.2.7 — 2026-09-23

- Align the Document properties date-format dropdown with other settings and prevent oversized dropdowns from overflowing narrow cards.

## 1.2.6 — 2026-09-23

- Add customizable Document properties date formats, spaced Chinese dates, and source time zones and seconds when available. Allow clicking outside the dialog to close it.
- Apply interface-language changes immediately to open readers and Settings pages.
- Show OCR results directly as selectable page text, with each page ready as soon as it is recognized.
- Default Text recognition to the current page, with choices for the current page and next 5/10 pages or the side panel; hold the button to open the panel from a direct-recognition mode.
- Enable English and Simplified Chinese recognition by default and improve spacing when copying recognized Chinese text.
- Use Chrome for ⌘F/Ctrl+F by default, with a Settings switch to use Cosmic PDF search instead.
- Size More actions to its contents, simplify Find labels and the Properties menu label, and mark default-hidden controls in Settings.

## 1.2.5 — 2026-09-23

- Let toolbar controls move into an icon-labeled More actions menu through Settings, with immediate updates to open readers.
- Simplify the toolbar when filename and branding are hidden, including moving Previous/next page into the menu while retaining the page counter and keeping Pages and outline at the left.
- Use a compact percentage input when fit controls are moved into the menu; accept values with or without `%`.
- Open reader Settings immediately to the right of the current PDF tab.
- Keep compact toolbars on one row whenever their visible controls fit, and reduce the README heading logo size.

## 1.2.3 — 2026-09-23

- Show the toolbar immediately while opening a PDF, with loading progress in its bottom divider instead of a separate loading screen.
- Add an on-demand Document properties dialog between Print and Settings.
- Prepare the PDF parser during download and prioritize the first page over optional thumbnails.
- Give current and total page counts equal, centered widths, and place custom zoom values between their neighboring presets.
- Hide the filename and Cosmic PDF branding by default while preserving saved choices.

## 1.2.2 — 2026-09-23

- Tighten spacing within the page-navigation and zoom controls while preserving button sizes and other toolbar spacing.

## 1.2.1 — 2026-09-23

- Simplify PDF loading to the Cosmic PDF logo, name, and progress bar, and prepare the reader while the file loads.
- Open homepage Settings in the same tab and improve browser Back/Forward navigation from the PDF reader.
- Add independent toolbar checkboxes for the filename and Cosmic PDF branding, including the option to hide both. Changes also apply to open readers.
- Use a compact layout with a single appearance button when either item is hidden, while preserving the original two-row controls when both are shown.
- Mark default appearance, reading, and OCR dropdown choices, and refine the README presentation and extension description.

## 1.1.6 — 2026-09-23

- Set the opening-screen copyright to 13px and center it vertically between the file hint and the card border.

## 1.1.5

- Adjust the Open PDF buttons on the opening screen and Settings page to 14px, and add a copyright line beneath the opening-screen hint.

## 1.1.3

- Set a 14px minimum for Cosmic PDF interface text, simplify the reader wordmark, and add a copyright line at the lower right of Settings.

## 1.1.2

- Align Settings, the opening screen and reader controls with Cosmic Gemini’s visual style, with a new document icon and clearer UI typography.
- Replace OCR language presets with independent English, Simplified Chinese and Traditional Chinese checkboxes.

## 1.1.1

- Introduce Cosmic PDF, an independent Chrome PDF reader derived from Cosmic Gemini's PDF Viewer feature.
- Add automatic opening of supported PDFs, light/dark themes and a return-to-Chrome-reader control.
- Add offline English, Simplified Chinese and Traditional Chinese OCR with selectable and copyable results.
- Provide reading, rendering and OCR preferences in English and Simplified Chinese.
