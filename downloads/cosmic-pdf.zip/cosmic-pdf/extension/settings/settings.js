import { createSettingsDropdowns } from './dropdowns.js';
import { createAiSettings } from './ai-settings.js';
import { createSettingsStore } from './store.js';
import { setReaderIcon } from '../workspaces/pdf-viewer/icons.js';
import { DEFAULTS, readSettings, uiLocale, TOOLBAR_ACTIONS, hiddenToolbarActions } from '../core/settings.js';
import { languageChoices } from '../shared/ocr-languages.js';
const claimSettings=openedAt=>void chrome.runtime.sendMessage({type:'SETTINGS_OPENED',openedAt}).catch(()=>{});
claimSettings(performance.timeOrigin);
addEventListener('pageshow',event=>{if(event.persisted)claimSettings(performance.timeOrigin+performance.now());});
const copy={
'en-US':{title:'Settings',intro:'Make Cosmic PDF feel right for the way you read.',open:'Open a PDF',reset:'Reset settings',confirm:'Reset all Cosmic PDF settings?',saved:'Saved',error:'Could not save. Please try again.',privacy:'PDF reading and OCR stay on this device. AI explanations send only the text you choose to your selected service. There is no analytics. Rendering quality and OCR language/detail changes apply to PDFs opened or reloaded afterward.',groups:['Opening & appearance','Reading & rendering','Text recognition'],
labels:{useChromeFind:['Use Chrome’s Find','Let Chrome handle ⌘F/Ctrl+F for loaded page text.'],enabled:['Open PDFs with Cosmic PDF','Automatically open supported PDF links in this reader. Downloads remain downloads.'],locale:['Interface language','Choose the language used in the reader and Settings.'],appearance:['Appearance','Choose a light or dark theme, or follow your browser.'],preserveDarkPaper:['Preserve dark-paper colors','Keep clearly identified dark-paper pages from becoming brighter in dark mode.'],sampling:['Rendering quality','Higher sampling makes text and fine details sharper but uses more memory.'],sharpening:['Sharpen page images','Apply mild sharpening. This uses additional graphics memory.'],zoom:['Default zoom','Set the initial size of each newly opened PDF.'],gap:['Page spacing','Adjust the space between pages.'],toolbar:['Toolbar content','Choose what appears in the toolbar.'],toolbarHidden:['More actions','Move selected controls into the More actions menu.'],sidebar:['Show page thumbnails on opening','Keep the page navigator open when a document starts.'],links:['Allow document links','Enable clickable links in the document.'],captureLinks:['Capture external links','Show an Open/Copy prompt for web and application links. Email, telephone, and SMS links always offer copying only.'],motion:['Interface animation','Animate loading indicators and small interface transitions.'],darkStrength:['Dark theme depth','Choose how dark the paper appears.'],automaticOcr:['Automatic text recognition','Automatically recognize the current page when it has no text layer.'],ocrLanguages:['OCR languages','Select one or more languages to recognize.'],ocrQuality:['OCR detail','Use higher detail for small text.'],ocrLayout:['OCR layout','Choose the layout that best describes the scanned page.'],ocrAction:['Text recognition button','Choose what a click does. Hold the button to open the panel when using direct recognition.'],propertyDateFormat:['Document properties date format','Choose how dates appear in Document properties.']},
tools:{pages:'Pages and outline',find:'Find',paging:'Previous/next page',zoom:'Zoom out/in',fit:'Fit width/page',rotate:'Rotate left',fullscreen:'Full screen',ocr:'Text recognition',print:'Print',properties:'Document properties',native:'Use Chrome reader'},
values:{defaultHidden:' (hidden by default)',dateAuto:'Language default',ocrPanel:'Open side panel',ocrPage:'Recognize current page',ocrNext5:'Current page and next 5 pages',ocrNext10:'Current page and next 10 pages',toolbarBranding:'Cosmic PDF branding',toolbarFilename:'Filename',auto:'Auto',light:'Light',dark:'Dark',english:'English',chinese:'简体中文',fitWidth:'Fit width',fitPage:'Fit page',px:'px',soft:'Soft',balanced:'Balanced',deep:'Deep',black:'Black',eng:'English',sim:'Simplified Chinese',tra:'Traditional Chinese',fast:'Fast',standard:'Balanced',fine:'Fine',layoutAuto:'Automatic',block:'Single text block',sparse:'Scattered text'}},
'zh-CN':{title:'设置',intro:'按照您的阅读习惯调整 Cosmic PDF。',open:'打开 PDF',reset:'重置设置',confirm:'是否重置 Cosmic PDF 的所有设置？',saved:'已保存',error:'保存失败，请重试。',privacy:'PDF 阅读和 OCR 均在本机处理。AI 解释仅将您选择的文字发送至所选服务，不收集使用数据。显示质量、OCR 语言和精细程度的修改适用于之后打开或刷新的 PDF。',groups:['打开方式与外观','阅读与显示','文字识别'],
labels:{useChromeFind:['使用 Chrome 的页面查找','将 ⌘F／Ctrl+F 交由 Chrome 查找已加载的页面文字。'],enabled:['使用 Cosmic PDF 打开 PDF','自动接管支持的 PDF 阅读链接，不改变正常的文件下载。'],locale:['界面语言','选择阅读器和设置页的语言。'],appearance:['外观','选择浅色、深色，或跟随浏览器。'],preserveDarkPaper:['保留深色纸张原色','避免让识别出的深色纸张在深色模式下变得更亮。'],sampling:['显示清晰度','提高采样倍数可改善文字和细节，但会增加内存占用。'],sharpening:['锐化页面图像','进行轻度锐化，此选项会增加图形内存占用。'],zoom:['默认缩放','设置新打开 PDF 的初始显示比例。'],gap:['页面间距','调整页面之间的空隙。'],toolbar:['工具栏内容','选择在工具栏中显示的内容。'],toolbarHidden:['更多操作','将勾选的工具收纳到“更多操作”菜单中。'],sidebar:['打开时显示页面缩略图','在打开文档时展开页面导航栏。'],links:['允许文档链接','允许点击文档中的链接。'],captureLinks:['捕获外部链接','网页和应用链接先显示打开／复制浮窗。邮件／电话／短信链接始终仅提供复制。'],motion:['界面动画','显示加载指示和轻量界面动画。'],darkStrength:['深色模式深度','调整深色模式下的纸张深浅。'],automaticOcr:['自动文字识别','当前页没有文字层时自动识别。'],ocrLanguages:['OCR 语言','勾选需要识别的语言，至少选择一项。'],ocrQuality:['OCR 精细程度','小字较多时可提高精细程度。'],ocrLayout:['OCR 排版','选择最符合扫描页面的文字排版。'],ocrAction:['文字识别按钮','选择单击按钮时的操作。使用直接识别时，长按可打开侧栏。'],propertyDateFormat:['文档信息日期格式','选择文档信息中的日期显示格式。']},
tools:{pages:'页面和目录',find:'查找',paging:'上一页／下一页',zoom:'缩小／放大',fit:'适合宽度／适合页面',rotate:'向左旋转',fullscreen:'全屏',ocr:'文字识别',print:'打印',properties:'文档信息',native:'使用 Chrome 阅读器'},
values:{defaultHidden:'（默认隐藏）',dateAuto:'语言默认格式',ocrPanel:'打开侧栏',ocrPage:'识别当前页',ocrNext5:'识别当前页和未来 5 页',ocrNext10:'识别当前页和未来 10 页',toolbarBranding:'Cosmic PDF 标识',toolbarFilename:'文件名',auto:'自动',light:'浅色',dark:'深色',english:'English',chinese:'简体中文',fitWidth:'适合宽度',fitPage:'适合页面',px:'像素',soft:'柔和',balanced:'适中',deep:'深黑',black:'纯黑',eng:'英文',sim:'简体中文',tra:'繁体中文',fast:'快速',standard:'均衡',fine:'精细',layoutAuto:'自动',block:'单一文本块',sparse:'分散文字'}}};
const actionIcons={pages:'sidebar-toggle',find:'search-toggle',paging:'next',zoom:'zoom-in',fit:'fit-width',rotate:'rotate',fullscreen:'fullscreen',ocr:'ocr-toggle',print:'print',properties:'properties',native:'native'};
const defaultHidden=new Set(hiddenToolbarActions(DEFAULTS));
const dropdowns=createSettingsDropdowns();
let aiSettings;
let state=await readSettings();const $=id=>document.getElementById(id);
const versionText='Cosmic PDF '+chrome.runtime.getManifest().version;
function showTestMode(enabled){const text=versionText+(enabled?' (Test mode)':'');if($('version').textContent!==text)$('version').textContent=text;}
showTestMode(false);
function render(){const locale=uiLocale(state,chrome.i18n.getUILanguage()),t=copy[locale],v=t.values;document.documentElement.lang=locale;document.title='Cosmic PDF · '+t.title;
 document.documentElement.dataset.dark=String(state.appearance==='dark'||(state.appearance==='auto'&&matchMedia('(prefers-color-scheme:dark)').matches));try{localStorage.setItem('appearance',state.appearance);}catch{}
 for(const [id,key] of [['title','title'],['intro','intro'],['open-reader','open'],['reset','reset'],['privacy','privacy']])$(id).textContent=t[key];
 const options={propertyDateFormat:[['auto',v.dateAuto],['ymd','2025-06-10 18:14'],['ymd-slash','2025/06/10 18:14'],['dmy','10/06/2025 18:14'],['mdy','06/10/2025 18:14']],ocrAction:[['page',v.ocrPage],['next5',v.ocrNext5],['next10',v.ocrNext10],['panel',v.ocrPanel]],locale:[['auto',v.auto],['en-US',v.english],['zh-CN',v.chinese]],appearance:[['auto',v.auto],['light',v.light],['dark',v.dark]],sampling:[1,2,3,4,5,6].map(n=>[n,n+'×']),zoom:[['page-width',v.fitWidth],['page-fit',v.fitPage],...[.5,.75,1,1.25,1.5,2].map(n=>[String(n).replace(/^0\./,'.'),n*100+'%'])],gap:[8,16,24,32].map(n=>[n,n+' '+v.px]),darkStrength:[[.85,v.soft],[.9,v.balanced],[.96,v.deep],[1,v.black]],ocrQuality:[[1.5,v.fast],[2,v.standard],[3,v.fine]],ocrLayout:[['3',v.layoutAuto],['6',v.block],['11',v.sparse]]};
 const groupKeys=[['enabled','locale','appearance','preserveDarkPaper','toolbar','toolbarHidden'],['sampling','sharpening','zoom','gap','sidebar','links','captureLinks','useChromeFind','motion','darkStrength','propertyDateFormat'],['automaticOcr','ocrAction','ocrLanguages','ocrQuality','ocrLayout']];
 $('groups').replaceChildren();groupKeys.forEach((keys,i)=>{const section=document.createElement('section'),h=document.createElement('h2'),card=document.createElement('div');h.textContent=t.groups[i];card.className='card';section.append(h,card);
 for(const key of keys){const row=document.createElement('div'),desc=document.createElement('div'),title=document.createElement('h3'),p=document.createElement('p');row.className='row';row.hidden=key==='preserveDarkPaper'&&state.appearance==='light';title.id=key+'-title';p.id=key+'-help';title.textContent=t.labels[key][0];p.textContent=t.labels[key][1];desc.append(title,p);let input;
 if(key==='toolbar'){
  const fieldset=document.createElement('fieldset'),options=document.createElement('div');fieldset.id='toolbar';fieldset.className='language-choices';fieldset.setAttribute('aria-labelledby',title.id);fieldset.setAttribute('aria-describedby',p.id);options.className='language-options';row.classList.add('languages');
  for(const [setting,label]of [['showFilename',v.toolbarFilename],['showBranding',v.toolbarBranding]]){const choice=document.createElement('label'),checkbox=document.createElement('input'),caption=document.createElement('span');checkbox.type='checkbox';checkbox.id=setting;checkbox.checked=state[setting];caption.textContent=label;checkbox.onchange=()=>save(setting,checkbox.checked);choice.append(checkbox,caption);options.append(choice);}
  fieldset.append(options);row.append(desc,fieldset);card.append(row);continue;
 }
 if(key==='toolbarHidden'){
  row.classList.add('toolbar-options');const fieldset=document.createElement('fieldset');fieldset.id=key;fieldset.className='language-choices';fieldset.setAttribute('aria-labelledby',title.id);fieldset.setAttribute('aria-describedby',p.id);
  const options=document.createElement('div');options.className='language-options';const hidden=new Set(hiddenToolbarActions(state));
  for(const action of TOOLBAR_ACTIONS){const label=document.createElement('label'),checkbox=document.createElement('input'),caption=document.createElement('span');checkbox.type='checkbox';checkbox.id='hide-'+action;checkbox.checked=hidden.has(action);caption.textContent=t.tools[action];if(defaultHidden.has(action)){const hint=document.createElement('span');hint.className='default-hint';hint.textContent=v.defaultHidden;caption.append(hint);}checkbox.onchange=()=>save(key,{[action]:checkbox.checked});const icon=document.createElement('span');icon.className='option-icon';setReaderIcon(icon,actionIcons[action]);label.append(checkbox,icon,caption);options.append(label);}
  fieldset.append(options);row.append(desc,fieldset);card.append(row);continue;
 }
 if(key==='ocrLanguages'){const fieldset=document.createElement('fieldset');fieldset.id=key;fieldset.className='language-choices';fieldset.setAttribute('aria-labelledby',title.id);fieldset.setAttribute('aria-describedby',p.id);row.classList.add('languages');languageChoices(fieldset,state.ocrLanguages,{eng:v.eng,chi_sim:v.sim,chi_tra:v.tra},value=>save(key,value));row.append(desc,fieldset);card.append(row);continue;}
 if(typeof DEFAULTS[key]==='boolean'){input=document.createElement('input');input.type='checkbox';input.checked=state[key];input.setAttribute('role','switch');}else{input=document.createElement('select');for(const [value,label]of options[key]){const option=document.createElement('option');option.value=value;option.textContent=label+((i>0||key==='appearance')&&key!=='propertyDateFormat'&&value===DEFAULTS[key]?(locale==='zh-CN'?'（默认）':' (default)'):'');input.append(option);}input.value=state[key];}
 input.id=key;input.setAttribute('aria-labelledby',title.id);input.setAttribute('aria-describedby',p.id);input.onchange=()=>{let value=input.type==='checkbox'?input.checked:input.value;if(typeof DEFAULTS[key]==='number')value=Number(value);save(key,value);};row.append(desc,input);card.append(row);} $('groups').append(section);});dropdowns.refresh();
}
function refresh(next) {
 aiSettings?.update(uiLocale(next,chrome.i18n.getUILanguage()),next);
 const previousLocale=uiLocale(state,chrome.i18n.getUILanguage());state=next;
 if(previousLocale!==uiLocale(state,chrome.i18n.getUILanguage())){render();return;}
 // Ordinary saves update values in place, preserving focus and open controls.
 document.documentElement.dataset.dark=String(state.appearance==='dark'||(state.appearance==='auto'&&matchMedia('(prefers-color-scheme:dark)').matches));
 try{localStorage.setItem('appearance',state.appearance);}catch{}
 for(const [key,value]of Object.entries(state)){
  const input=$(key);if(!input||input.closest('#ai-settings')||!['INPUT','SELECT'].includes(input.tagName))continue;
  if(input.type==='checkbox')input.checked=value;else input.value=value;
 }
 $('preserveDarkPaper').closest('.row').hidden=state.appearance==='light';
 dropdowns.refresh();
 const hidden=new Set(hiddenToolbarActions(state));for(const action of TOOLBAR_ACTIONS)$('hide-'+action).checked=hidden.has(action);
 for(const input of $('ocrLanguages').querySelectorAll('input')){input.checked=state.ocrLanguages.includes(input.value);if(input.checked&&state.ocrLanguages.length===1)input.setAttribute('aria-disabled','true');else input.removeAttribute('aria-disabled');}
}
const store=createSettingsStore(state,{read:readSettings,write:async(_next,edit)=>{const result=await chrome.runtime.sendMessage({type:'SAVE_SETTING',edit});if(!result?.ok)throw Error('save');},changed:refresh});
function report(result){void result.then(()=>{$('saved').textContent=copy[uiLocale(state,chrome.i18n.getUILanguage())].saved;},()=>{$('saved').textContent=copy[uiLocale(state,chrome.i18n.getUILanguage())].error;});}
function save(key,value){report(store.save(key,value));}
$('open-reader').onclick=()=>location.assign(chrome.runtime.getURL('workspaces/pdf-reader/index.html'));
$('reset').onclick=()=>{const t=copy[uiLocale(state,chrome.i18n.getUILanguage())];if(confirm(t.confirm))report(store.reset());};
matchMedia('(prefers-color-scheme:dark)').addEventListener('change',()=>{if(state.appearance==='auto')document.documentElement.dataset.dark=String(matchMedia('(prefers-color-scheme:dark)').matches);});render();
aiSettings=createAiSettings({container:$('ai-settings'),locale:uiLocale(state,chrome.i18n.getUILanguage()),state,save,dropdowns,onTestMode:showTestMode});

// Refresh file-scheme eligibility when the settings page is reopened.
void chrome.runtime.sendMessage({type:'SETTINGS_SAVED'}).catch(()=>{});

// All saved preferences synchronize; pending local edits retain priority.
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area==='local'&&changes.settings)store.receive(changes.settings.newValue);
});
