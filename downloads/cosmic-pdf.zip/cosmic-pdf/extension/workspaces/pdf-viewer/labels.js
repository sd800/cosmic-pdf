export const labels = {
  'en-US': {
    theme:'Switch light/dark mode', themeMenu:'Appearance', themeAuto:'Auto', themeLight:'Light', themeDark:'Dark', print:'Print', download:'Download original', sidebar:'Pages and outline', find:'Find', previous:'Previous page', next:'Next page', page:'Page', zoom:'Zoom', zoomOut:'Zoom out', zoomIn:'Zoom in', fitWidth:'Fit width', fitPage:'Fit page', rotate:'Rotate left', fullscreen:'Full screen', exitFullscreen:'Exit full screen', fullScreenFailed:'Full screen is not available in this window.', matchCase:'Match case', previousMatch:'Previous match', nextMatch:'Next match', close:'Close', pages:'Pages', outline:'Outline', password:'Password', cancel:'Cancel', open:'Open', loading:'Opening PDF…', failed:'This PDF could not be displayed. You can still download the original.', noOutline:'This document has no outline.', passwordNeeded:'Enter the password to open this PDF.', passwordWrong:'Incorrect password. Please try again.', noMatches:'No matches', searching:'Searching…', pageError:'A page could not be rendered. Try changing the zoom or download the original.', cancelled:'Opening cancelled. You can download the original.'
  },
  'zh-CN': {
    theme:'切换浅色／深色模式', themeMenu:'外观', themeAuto:'自动', themeLight:'浅色', themeDark:'深色', print:'打印', download:'下载原文件', sidebar:'页面和目录', find:'查找', previous:'上一页', next:'下一页', page:'页码', zoom:'缩放', zoomOut:'缩小', zoomIn:'放大', fitWidth:'适合宽度', fitPage:'适合页面', rotate:'向左旋转', fullscreen:'全屏', exitFullscreen:'退出全屏', fullScreenFailed:'当前窗口无法进入全屏。', matchCase:'区分大小写', previousMatch:'上一个匹配项', nextMatch:'下一个匹配项', close:'关闭', pages:'页面', outline:'目录', password:'密码', cancel:'取消', open:'打开', loading:'正在打开 PDF…', failed:'无法显示此 PDF，您仍可下载原文件。', noOutline:'此文档没有目录。', passwordNeeded:'请输入密码以打开此 PDF。', passwordWrong:'密码不正确，请重试。', noMatches:'没有匹配项', searching:'正在查找…', pageError:'有页面未能显示，请尝试调整缩放比例或下载原文件。', cancelled:'已取消打开，您仍可下载原文件。'
  }
};

Object.assign(labels['en-US'], {settings:'Settings',menuNative:'Chrome reader',native:'Use Chrome reader',ocr:'Text recognition',ocrIntro:'Recognize scanned text locally, then select and copy it on the page. The original file is not changed.',ocrLanguage:'Languages',ocrLanguageHelp:'Select one or more languages.',ocrEnglish:'English',ocrSimplified:'Simplified Chinese',ocrTraditional:'Traditional Chinese',ocrLimit:'Up to 20 pages per run. You can keep reading while recognition runs.',recognize:'Recognize',ocrResult:'Recognized text',clear:'Clear results',ocrLoading:'Preparing local recognition…',ocrReading:'Recognizing page',ocrDone:'Recognition complete.',ocrFailed:'Recognition could not finish. Try fewer pages or lower OCR detail.',ocrCancelled:'Recognition stopped.',ocrEmpty:'No text was recognized on this page.',ocrInvalid:'Choose a valid range of up to 20 pages.',ocrNoPermission:'This document does not allow text extraction.'});
Object.assign(labels['zh-CN'], {settings:'设置',menuNative:'Chrome 阅读器',native:'使用 Chrome 阅读器',ocr:'文字识别',ocrIntro:'在本机识别扫描文字，然后直接在页面上选择和复制，不修改原文件。',ocrLanguage:'识别语言',ocrLanguageHelp:'至少选择一项，可同时识别多种语言。',ocrEnglish:'英文',ocrSimplified:'简体中文',ocrTraditional:'繁体中文',ocrLimit:'每次最多识别 20 页，识别期间可继续阅读。',recognize:'开始识别',ocrResult:'识别文字',clear:'清除结果',ocrLoading:'正在准备本地识别…',ocrReading:'正在识别页面',ocrDone:'识别完成。',ocrFailed:'未能完成识别，请减少页数或降低 OCR 精细程度。',ocrCancelled:'已停止识别。',ocrEmpty:'此页未识别到文字。',ocrInvalid:'请选择有效的页码范围，每次最多 20 页。',ocrNoPermission:'此文档不允许提取文字。'});

Object.assign(labels['en-US'], {properties:'Document properties', propertiesLoading:'Reading document properties…', propertiesUnavailable:'Some document properties could not be read.', fileName:'File name', fileUrl:'File URL', fileSize:'File size', documentTitle:'Title', author:'Author', subject:'Subject', keywords:'Keywords', created:'Created', modified:'Modified', application:'Application', producer:'PDF producer', pdfVersion:'PDF version', pageCount:'Page count', pageSize:'Page size', fastWebView:'Fast web view', yes:'Yes', no:'No'});
Object.assign(labels['zh-CN'], {properties:'文档信息', propertiesLoading:'正在读取文档信息…', propertiesUnavailable:'部分文档信息无法读取。', fileName:'文件名', fileUrl:'文件 URL', fileSize:'文件大小', documentTitle:'标题', author:'作者', subject:'主题', keywords:'关键词', created:'创建时间', modified:'修改时间', application:'创建应用', producer:'PDF 生成程序', pdfVersion:'PDF 版本', pageCount:'页数', pageSize:'页面尺寸', fastWebView:'快速 Web 查看', yes:'是', no:'否'});

Object.assign(labels['en-US'],{moreActions:'More actions',menuProperties:'Properties'});
Object.assign(labels['zh-CN'],{moreActions:'更多操作',menuProperties:'文档信息'});

Object.assign(labels['en-US'],{aiToggle:'AI explanations'});
Object.assign(labels['zh-CN'],{aiToggle:'AI 解释'});

Object.assign(labels['en-US'], {annotations:'Show annotations and filled forms'});
Object.assign(labels['zh-CN'], {annotations:'显示批注和已填表单'});

Object.assign(labels['en-US'],{themeMenu:'Appearance',themeAuto:'Auto',themeLight:'Light',themeDark:'Dark',themeGlobal:'All pages',themePage:'Current page'});
Object.assign(labels['zh-CN'],{themeMenu:'外观',themeAuto:'自动',themeLight:'浅色',themeDark:'深色',themeGlobal:'全部页面',themePage:'当前页'});

Object.assign(labels['en-US'],{themeFollowDocument:'Follow the appearance of all pages'});
Object.assign(labels['zh-CN'],{themeFollowDocument:'跟随全部页面的外观'});
